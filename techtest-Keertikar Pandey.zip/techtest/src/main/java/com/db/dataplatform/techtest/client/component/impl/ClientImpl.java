package com.db.dataplatform.techtest.client.component.impl;

import com.db.dataplatform.techtest.client.api.model.DataEnvelope;
import com.db.dataplatform.techtest.client.component.Client;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.db.dataplatform.techtest.Constant.*;

/**
 * Client code does not require any test coverage
 */

@Service
@Slf4j
@RequiredArgsConstructor
public class ClientImpl implements Client {

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public void pushData(DataEnvelope dataEnvelope) {
        log.info("Pushing data {} to {}", dataEnvelope.getDataHeader().getName(), URI_PUSHDATA);

        ResponseEntity<Boolean> responseEntity = restTemplate.postForEntity(URI_PUSHDATA, dataEnvelope, Boolean.class);
        log.info("Checksum matched: {}", responseEntity.getBody());
    }

    @Override
    public List<DataEnvelope> getData(String blockType) {
        log.info("Query for data with header block type {}", blockType);
        ResponseEntity<List> responseEntity = restTemplate.getForEntity(URI_GETDATA.toString(), List.class, blockType);
        log.info("Got Response - Status: {}, BlockData: {}", responseEntity.getStatusCode(), responseEntity.getBody());
        return responseEntity.getBody();
    }

    @Override
    public boolean updateData(String name, String newBlockType) {
        log.info("Updating blocktype to {} for block with name {}", newBlockType, name);
        Map<String, String> params = new HashMap();
        params.put("name",name);
        params.put("newBlockType",newBlockType);
        restTemplate.put(URI_PATCHDATA.toString(), null, params);
        return true;
    }


}
