package com.db.dataplatform.techtest.server.component;

import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.client.HttpServerErrorException;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;

public interface Server {
    boolean saveDataEnvelope(DataEnvelope envelope) throws IOException, NoSuchAlgorithmException;

    List<DataEnvelope> findAllBy(BlockTypeEnum blockType);

    boolean updateDataHeader(String name, String blockType);

    Optional<DataBodyEntity> getDataByBlockName(String blockName);

    @Retryable(value = { HttpServerErrorException.class }, maxAttempts = 5)
    void saveToHadoopFileSystem(DataEnvelope envelope);
}
