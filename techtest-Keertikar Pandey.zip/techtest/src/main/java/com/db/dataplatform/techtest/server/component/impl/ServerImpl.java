package com.db.dataplatform.techtest.server.component.impl;

import com.db.dataplatform.techtest.server.api.model.DataBody;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.api.model.DataHeader;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import com.db.dataplatform.techtest.server.service.DataHeaderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.db.dataplatform.techtest.Constant.URI_PUSHBIGDATA;

@Slf4j
@Service
@RequiredArgsConstructor
public class ServerImpl implements Server {

    private final DataBodyService dataBodyService;
    private final DataHeaderService dataHeaderService;
    private final ModelMapper modelMapper;
    private final RestTemplate restTemplate;

    /**
     * @param envelope
     * @return true if there is a match with the client provided checksum.
     */
    @Override
    public boolean saveDataEnvelope(DataEnvelope envelope) {

        // Save to persistence.
        persist(envelope);
        log.info("Data persisted successfully, data name: {}", envelope.getDataHeader().getName());

        final String dataBodyMd5CheckSum = DigestUtils.md5Hex(envelope.getDataBody().getDataBody());
        return StringUtils.equals(envelope.getDataBody().getCheckSum(), dataBodyMd5CheckSum);
    }

    public void saveToHadoopFileSystem(DataEnvelope envelope) {
        log.info("Pushing data to HadoopFileSystem");
        restTemplate.postForEntity(URI_PUSHBIGDATA, envelope, ResponseEntity.class);
    }

    @Override
    public List<DataEnvelope> findAllBy(BlockTypeEnum blockType) {
        List<DataBodyEntity> dataBodyEntities = dataBodyService.getDataByBlockType(blockType);
        return dataBodyEntities.stream()
                .map(dataBodyEntity ->
                        new DataEnvelope(
                                new DataHeader(dataBodyEntity.getDataHeaderEntity().getName(), dataBodyEntity.getDataHeaderEntity().getBlocktype()),
                                new DataBody(dataBodyEntity.getDataBody(), dataBodyEntity.getCheckSum())))
                .collect(Collectors.toList());
    }

    @Override
    public boolean updateDataHeader(String name, String blockType) {
        log.info("Persisting DataHeaderEntity with name: {}, blockType value {}", name, blockType);
        dataHeaderService.updateDataHeader(name, BlockTypeEnum.valueOf(blockType));
        return true;
    }

    @Override
    public Optional<DataBodyEntity> getDataByBlockName(String blockName) {
        return dataBodyService.getDataByBlockName(blockName);
    }

    private void persist(DataEnvelope envelope) {
        log.info("Persisting data with attribute name: {}", envelope.getDataHeader().getName());
        DataHeaderEntity dataHeaderEntity = modelMapper.map(envelope.getDataHeader(), DataHeaderEntity.class);

        DataBodyEntity dataBodyEntity = modelMapper.map(envelope.getDataBody(), DataBodyEntity.class);
        dataBodyEntity.setDataHeaderEntity(dataHeaderEntity);

        saveData(dataBodyEntity);
    }

    private void saveData(DataBodyEntity dataBodyEntity) {
        dataBodyService.saveDataBody(dataBodyEntity);
    }

}
