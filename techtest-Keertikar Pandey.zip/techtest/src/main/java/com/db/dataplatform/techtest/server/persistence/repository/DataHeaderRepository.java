package com.db.dataplatform.techtest.server.persistence.repository;

import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface DataHeaderRepository extends JpaRepository<DataHeaderEntity, Long> {

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update DataHeaderEntity set blocktype = :blockType where name = :name")
    void updateBlockType(@Param("name") String name, @Param("blockType") BlockTypeEnum blockType);

}
