package com.db.dataplatform.techtest.server.service.impl;

import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.repository.DataStoreRepository;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DataBodyServiceImpl implements DataBodyService {

    private final DataStoreRepository dataStoreRepository;

    @Override
    public void saveDataBody(DataBodyEntity dataBody) {
        dataStoreRepository.save(dataBody);
    }

    @Override
    public List<DataBodyEntity> getDataByBlockType(BlockTypeEnum blockType) {
        return dataStoreRepository.findAll()
                .stream()
                .filter(item -> blockType.equals(item.getDataHeaderEntity().getBlocktype()))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<DataBodyEntity> getDataByBlockName(String blockName) {
        Optional<DataBodyEntity> dataBodyEntity = dataStoreRepository.findAll()
                .stream()
                .filter(item -> blockName.equals(item.getDataHeaderEntity().getName()))
                .findFirst();
        return dataBodyEntity.isPresent() ? dataBodyEntity : Optional.empty();
    }
}
