package com.db.dataplatform.techtest.api.controller;

import com.db.dataplatform.techtest.TestDataHelper;
import com.db.dataplatform.techtest.server.api.controller.ServerController;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.exception.HadoopClientException;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.service.DataHeaderService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Optional;

import static com.db.dataplatform.techtest.Constant.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

@RunWith(MockitoJUnitRunner.class)
public class ServerControllerComponentTest {

	@Mock private Server serverMock;

	private DataEnvelope testDataEnvelope;
	private ObjectMapper objectMapper;
	private MockMvc mockMvc;
	private ServerController serverController;

	@Before
	public void setUp() throws HadoopClientException, NoSuchAlgorithmException, IOException {
		serverController = new ServerController(serverMock);
		mockMvc = standaloneSetup(serverController).build();
		objectMapper = Jackson2ObjectMapperBuilder.json().build();

		testDataEnvelope = TestDataHelper.createTestDataEnvelopeApiObject();
		when(serverMock.saveDataEnvelope(any(DataEnvelope.class))).thenReturn(true);
	}

	@Test
	public void testPushDataPostCallWorksAsExpected() throws Exception {
		String testDataEnvelopeJson = objectMapper.writeValueAsString(testDataEnvelope);

		MvcResult mvcResult = mockMvc.perform(post(URI_PUSHDATA)
				.content(testDataEnvelopeJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(status().isOk())
				.andReturn();

		boolean checksumPass = Boolean.parseBoolean(mvcResult.getResponse().getContentAsString());
		assertThat(checksumPass).isTrue();
		verify(serverMock, times(1)).saveDataEnvelope(any());
		verify(serverMock, times(1)).saveToHadoopFileSystem(any());
	}

	@Test
	public void testGetData() throws Exception {
		when(serverMock.findAllBy(any())).thenReturn(Arrays.asList(testDataEnvelope));
		MvcResult mvcResult = mockMvc.perform(get(URI_GETDATA.toString(), BlockTypeEnum.BLOCKTYPEA))
				.andExpect(status().isOk())
				.andReturn();
		JsonNode jsonNode = objectMapper.readTree(mvcResult.getResponse().getContentAsString());
		assertThat(jsonNode.size()).isEqualTo(1);
		verify(serverMock, times(1)).findAllBy(any());
	}

	@Test
	public void testUpdateWithExistingBlockName() throws Exception {
		Optional<DataBodyEntity> testDataBodyEntity = Optional.of(TestDataHelper.createTestDataBodyEntity(TestDataHelper.createTestDataHeaderEntity(Instant.now())));
		when(serverMock.getDataByBlockName(anyString())).thenReturn(testDataBodyEntity);
		mockMvc.perform(put(URI_PATCHDATA.toString(), "Test", BlockTypeEnum.BLOCKTYPEA))
				.andExpect(status().isOk())
				.andReturn();
		verify(serverMock, times(1)).getDataByBlockName(anyString());
		verify(serverMock, times(1)).updateDataHeader(anyString(), any());
	}

	@Test
	public void testUpdateWithNonExistingBlockName() throws Exception {
		when(serverMock.getDataByBlockName(anyString())).thenReturn(Optional.empty());
		mockMvc.perform(put(URI_PATCHDATA.toString(), "Test", BlockTypeEnum.BLOCKTYPEA))
				.andExpect(status().isNotFound())
				.andReturn();
		verify(serverMock, times(1)).getDataByBlockName(anyString());
	}

}
