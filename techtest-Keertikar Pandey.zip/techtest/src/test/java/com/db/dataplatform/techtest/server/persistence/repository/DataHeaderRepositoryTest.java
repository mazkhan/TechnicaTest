package com.db.dataplatform.techtest.server.persistence.repository;

import com.db.dataplatform.techtest.client.component.Client;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Optional;

import static com.db.dataplatform.techtest.server.persistence.BlockTypeEnum.BLOCKTYPEA;
import static com.db.dataplatform.techtest.server.persistence.BlockTypeEnum.BLOCKTYPEB;
import static java.time.Instant.now;
import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class DataHeaderRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;
    @Autowired private DataHeaderRepository repository;

    @MockBean Client client;

    @Test
    void testSaveDataHeaderEntity() {
        DataHeaderEntity testInput = new DataHeaderEntity();
        testInput.setBlocktype(BLOCKTYPEA);
        testInput.setCreatedTimestamp(now());
        testInput.setName("Test-1");
        DataHeaderEntity createdEntity = entityManager.persist(testInput);

        Optional<DataHeaderEntity> result = repository.findById(createdEntity.getDataHeaderId());
        assertThat(result.get().getName()).isEqualTo(testInput.getName());
    }

    @Test
    void testUpdateDataHeaderEntity() {
        DataHeaderEntity testInput = new DataHeaderEntity();
        testInput.setBlocktype(BLOCKTYPEA);
        testInput.setCreatedTimestamp(now());
        testInput.setName("Test-1");
        DataHeaderEntity createdEntity = entityManager.persist(testInput);

        // Verify save
        Optional<DataHeaderEntity> result = repository.findById(createdEntity.getDataHeaderId());
        assertThat(result.get().getBlocktype()).isEqualTo(BLOCKTYPEA);

        // Update now & re-fetch
        repository.updateBlockType(testInput.getName(), BLOCKTYPEB);
        result = repository.findById(createdEntity.getDataHeaderId());
        assertThat(result.get().getBlocktype()).isEqualTo(BLOCKTYPEB);
    }
}