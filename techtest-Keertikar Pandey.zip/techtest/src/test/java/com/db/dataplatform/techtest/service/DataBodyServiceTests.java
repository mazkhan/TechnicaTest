package com.db.dataplatform.techtest.service;

import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.persistence.repository.DataStoreRepository;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import com.db.dataplatform.techtest.server.service.impl.DataBodyServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.db.dataplatform.techtest.TestDataHelper.createTestDataBodyEntity;
import static com.db.dataplatform.techtest.TestDataHelper.createTestDataHeaderEntity;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class DataBodyServiceTests {

    public static final String TEST_NAME_NO_RESULT = "TestNoResult";

    @Mock
    private DataStoreRepository dataStoreRepositoryMock;

    private DataBodyService dataBodyService;
    private DataBodyEntity expectedDataBodyEntity;

    @Before
    public void setup() {
        dataBodyService = new DataBodyServiceImpl(dataStoreRepositoryMock);
    }

    @Test
    public void shouldSaveDataBodyEntityAsExpected() {
        DataHeaderEntity testDataHeaderEntity = createTestDataHeaderEntity(Instant.now());
        expectedDataBodyEntity = createTestDataBodyEntity(testDataHeaderEntity);

        dataBodyService.saveDataBody(expectedDataBodyEntity);

        verify(dataStoreRepositoryMock, times(1))
                .save(eq(expectedDataBodyEntity));
    }

    @Test
    public void shouldReturnListWithMatchingBlockType() {
        DataBodyEntity entity1 = createTestDataBodyEntity(createTestDataHeaderEntity(Instant.now()));
        DataHeaderEntity testDataHeaderEntity = createTestDataHeaderEntity(Instant.now());
        testDataHeaderEntity.setBlocktype(BlockTypeEnum.BLOCKTYPEB);
        DataBodyEntity entity2 = createTestDataBodyEntity(testDataHeaderEntity);

        when(dataStoreRepositoryMock.findAll()).thenReturn(Arrays.asList(entity1, entity2));

        List<DataBodyEntity> dataByBlockType = dataBodyService.getDataByBlockType(BlockTypeEnum.BLOCKTYPEA);
        assertThat(dataByBlockType.size()).isEqualTo(1);

        verify(dataStoreRepositoryMock, times(1)).findAll();
    }

    @Test
    public void shouldReturnEmptyListWhenNoMatchingBlockType() {
        DataBodyEntity entity1 = createTestDataBodyEntity(createTestDataHeaderEntity(Instant.now()));
        DataHeaderEntity testDataHeaderEntity = createTestDataHeaderEntity(Instant.now());
        DataBodyEntity entity2 = createTestDataBodyEntity(testDataHeaderEntity);

        when(dataStoreRepositoryMock.findAll()).thenReturn(Arrays.asList(entity1, entity2));

        List<DataBodyEntity> dataByBlockType = dataBodyService.getDataByBlockType(BlockTypeEnum.BLOCKTYPEB);
        assertThat(dataByBlockType.size()).isZero();

        verify(dataStoreRepositoryMock, times(1)).findAll();
    }

    @Test
    public void shouldReturnWithExistingBlockName() {
        DataBodyEntity entity1 = createTestDataBodyEntity(createTestDataHeaderEntity(Instant.now()));
        when(dataStoreRepositoryMock.findAll()).thenReturn(Arrays.asList(entity1));

        Optional<DataBodyEntity> dataBodyEntity = dataBodyService.getDataByBlockName("Test");
        assertThat(dataBodyEntity.isPresent()).isTrue();
        verify(dataStoreRepositoryMock, times(1)).findAll();
    }

    @Test
    public void shouldReturnEmptyWithNonExistingBlockName() {
        when(dataStoreRepositoryMock.findAll()).thenReturn(Collections.emptyList());
        Optional<DataBodyEntity> dataBodyEntity = dataBodyService.getDataByBlockName("Test");
        assertThat(dataBodyEntity.isPresent()).isFalse();
        verify(dataStoreRepositoryMock, times(1)).findAll();
    }
}
