package com.db.dataplatform.techtest.service;

import com.db.dataplatform.techtest.TestDataHelper;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.mapper.ServerMapperConfiguration;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.component.impl.ServerImpl;
import com.db.dataplatform.techtest.server.service.DataHeaderService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.db.dataplatform.techtest.Constant.DUMMY_DATA;
import static com.db.dataplatform.techtest.TestDataHelper.createTestDataEnvelopeApiObject;
import static com.db.dataplatform.techtest.TestDataHelper.createTestDataHeaderEntity;
import static com.db.dataplatform.techtest.server.persistence.BlockTypeEnum.BLOCKTYPEA;
import static com.db.dataplatform.techtest.server.persistence.BlockTypeEnum.BLOCKTYPEB;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ServerServiceTests {

    @Mock private RestTemplate restTemplate;
    @Mock private DataBodyService dataBodyServiceImplMock;
    @Mock private DataHeaderService dataHeaderServiceImplMock;

    private ModelMapper modelMapper;
    private DataBodyEntity expectedDataBodyEntity;
    private DataEnvelope testDataEnvelope;

    private Server server;

    @Before
    public void setup() {
        ServerMapperConfiguration serverMapperConfiguration = new ServerMapperConfiguration();
        modelMapper = serverMapperConfiguration.createModelMapperBean();
        server = new ServerImpl(dataBodyServiceImplMock, dataHeaderServiceImplMock, modelMapper, restTemplate);
    }

    @Test
    public void shouldSaveDataEnvelopeAsExpected() throws NoSuchAlgorithmException, IOException {
        DataEnvelope testDataEnvelope = createTestDataEnvelopeApiObject();
        boolean success = server.saveDataEnvelope(testDataEnvelope);

        assertThat(success).isTrue();
        verify(dataBodyServiceImplMock, times(1)).saveDataBody(any());
    }

    @Test
    public void shouldSaveDataEnvelopeButChecksumMatchFails() throws NoSuchAlgorithmException, IOException {
        DataEnvelope testDataEnvelope = createTestDataEnvelopeApiObject(DUMMY_DATA, "xyz");
        boolean success = server.saveDataEnvelope(testDataEnvelope);

        assertThat(success).isFalse();
        verify(dataBodyServiceImplMock, times(1)).saveDataBody(any());
    }

    @Test
    public void shouldSaveDataButChecksumMatchFailsWithNullCheckSum() throws NoSuchAlgorithmException, IOException {
        DataEnvelope testDataEnvelope = createTestDataEnvelopeApiObject(DUMMY_DATA, null);
        boolean success = server.saveDataEnvelope(testDataEnvelope);

        assertThat(success).isFalse();
        verify(dataBodyServiceImplMock, times(1)).saveDataBody(any());
    }

    @Test
    public void shouldSaveDataButChecksumMatchSucceedsWithEmptyDataAndItsCheckSum() throws NoSuchAlgorithmException, IOException {
        DataEnvelope testDataEnvelope = createTestDataEnvelopeApiObject("", "d41d8cd98f00b204e9800998ecf8427e");
        boolean success = server.saveDataEnvelope(testDataEnvelope);

        assertThat(success).isTrue();
        verify(dataBodyServiceImplMock, times(1)).saveDataBody(any());
    }

    @Test
    public void findAllBy_WithNoMatchingBlockType() {
        when(dataBodyServiceImplMock.getDataByBlockType(any())).thenReturn(Collections.emptyList());

        assertThat(server.findAllBy(BLOCKTYPEB).size()).isZero();
        verify(dataBodyServiceImplMock, times(1)).getDataByBlockType(any());
    }

    @Test
    public void findAllBy_WithMatchingBlockType() {
        when(dataBodyServiceImplMock.getDataByBlockType(any()))
                .thenReturn(Collections.singletonList(
                        TestDataHelper.createTestDataBodyEntity(createTestDataHeaderEntity(Instant.now()))));
        assertThat(server.findAllBy(BLOCKTYPEB).size()).isEqualTo(1);
        verify(dataBodyServiceImplMock, times(1)).getDataByBlockType(any());
    }

    @Test
    public void shouldUpdateDataHeader() {
        assertThat(server.updateDataHeader("Test", BLOCKTYPEA.name())).isTrue();
        verify(dataHeaderServiceImplMock, times(1)).updateDataHeader(anyString(), any());
    }

    @Test
    public void dataByBlockName() {
        server.getDataByBlockName("ANY");
        verify(dataBodyServiceImplMock, times(1)).getDataByBlockName(anyString());
    }

    @Test
    public void shouldSaveToHadoopFileSystem() {
        DataEnvelope testDataEnvelope = createTestDataEnvelopeApiObject(DUMMY_DATA, "xyz");
        server.saveToHadoopFileSystem(testDataEnvelope);

        verify(restTemplate, times(1)).postForEntity(anyString(), any(), any());
    }
}
